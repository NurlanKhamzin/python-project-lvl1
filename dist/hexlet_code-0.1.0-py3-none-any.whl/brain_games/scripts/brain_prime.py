from brain_games.games import prime


def main():
    prime.game5()


if __name__ == '__main__':
    main()
