from brain_games.games import even
from brain_games.engine import engine


def main():
    engine(even)


if __name__ == '__main__':
    main()
