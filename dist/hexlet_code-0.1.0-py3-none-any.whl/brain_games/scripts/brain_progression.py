from brain_games.games import progression


def main():
    progression.game4()


if __name__ == '__main__':
    main()
