from brain_games.games import calc


def main():
    calc.game2()


if __name__ == '__main__':
    main()
