from brain_games.games import even


def main():
    even.game1()


if __name__ == '__main__':
    main()
